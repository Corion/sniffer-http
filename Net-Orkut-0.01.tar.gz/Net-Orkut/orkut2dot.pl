#!/usr/bin/perl -w
# Copyright (C) 2004 by Santeri Hernej�rvi.

# This library is free software; you can redistribute it and/or modify
# it under the same terms as Perl itself, either Perl version 5.8.1 or,
# at your option, any later version of Perl 5 you may have available.

# This example generates a Graphviz compatible file, which
# when processed with neato, yields a nice graph of your and
# your friends relationships.

require Net::Orkut;
use strict;

# You'll have to provide your own username and password.
my $o = Net::Orkut->new(user   => 'username', 
				        passwd => 'password');

my $uid = $o->login();

my $friendsHTML = $o->getFriendsPage($uid);
my %friends = $o->friends($friendsHTML);

graphHeader();

graphBodyFromHTML($friendsHTML);

foreach my $key (keys %friends) {
    my $friendsHTML = $o->getFriendsPage($key);
    graphBodyFromHTML($friendsHTML);
}

graphEnd();


sub graphHeader {
    print "graph friends {\n".
		  "graph [overlap=scale, sep=.1,splines=false];\n".
		  "edge [len=.1];".
		  "node [shape=box,fontsize=8];";
}

sub graphBodyFromHTML {
    $_ = shift;
    my $current = '';
    my @foo = split('<a');
    for (@foo) {
		# <a href="Profile.aspx?uid=810324467182223912" class="P">Santeri Hernej
		if (/Profile\.aspx\?uid=(\d+)\" class=\"P\">(.*)<\/a>/smg) {
			# The first one is the full name.
			if ($current eq '') {
				$current = $2;
			}
		}
		if (/FriendsList\.aspx\?uid=(\d+)\" class=\"P\">(.*)<\/a>/smg) {
			if (! /<img/) {
				my $foo = $2;
				chomp $foo;
				$foo =~ s/<\/?b>//g;
				print "\"$current\" -- \"$foo\";\n";
			}
		}
    }
}

sub graphEnd {
    print "}\n";
}
