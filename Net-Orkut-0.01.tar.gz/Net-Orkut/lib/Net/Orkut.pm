package Net::Orkut;

use 5.008001;
use strict;
use warnings;

require Exporter;

use AutoLoader qw(AUTOLOAD);

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration	use Net::Orkut ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
								   
								   ) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(

				 );

our $VERSION = '0.01';


# Preloaded methods go here.

# Autoload methods go after =cut, and are processed by the autosplit program.

1;
__END__
# Below is stub documentation for your module. You'd better edit it!

=head1 NAME

Net::Orkut - Perl extension for orkut.com online community.

=head1 SYNOPSIS

  use Net::Orkut;

  my $o = Net::Orkut->new(user   => 'username', 
				        passwd => 'password');

  my $uid = $o->login();

  my $friendsHTML = $o->getFriendsPage($uid);
  my %friends = $o->friends($friendsHTML);

=head1 DESCRIPTION

Blah blah blah.


=head1 SEE ALSO

=head1 AUTHOR

Santeri Hernej�rvi  E<lt>gray@gray.mine.nuE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2004 by Santeri Hernej�rvi.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.1 or,
at your option, any later version of Perl 5 you may have available.

=cut


=item $o = Net::Orkut->new( %options );
=head1 DESCRIPTION

This class method constructs a new C<Net::Orkut> client object and
returns a reference to it.

Key/value pair arguments may be provided to set up the initial state
of the user agent.  The following options correspond to attribute
methods described below:

   KEY                     DEFAULT
   -----------             --------------------
   user                    ""
   passwd                  ""

=cut

use Carp;
use LWP::UserAgent;
use HTTP::Request;

sub new {
	
    my($class, %cnf) = @_;
	
	my $user = delete $cnf{user};
	Carp::croak("Need a username!") unless defined $user;
	
	my $passwd = delete $cnf{passwd};
	Carp::croak("Need a password!") unless defined $passwd;
	
	if (%cnf && $^W) {
		Carp::carp("Unrecognized Net::Orkut ptions: @{[sort keys %cnf]}");
	}

	my $ua = new LWP::UserAgent;
	$ua->agent("Mozilla/5.0");


	my $self = bless {
		user   => $user,
		passwd => $passwd,
		cookie => undef,
		ua     => $ua
		}, $class;

	return $self;
}


=item $o->login();

=head1 DESCRIPTION

Logs in.

=cut

sub login {
	my $self = shift;

    # Login
    my $req = new HTTP::Request( POST =>'http://www.orkut.com/Login.aspx');
    $req->content_type('application/x-www-form-urlencoded');
    $req->content("u=$self->{user}&p=$self->{passwd}");
    my $res = $self->{ua}->request($req);
    
    $self->{cookie} = $res->headers->header('Set-Cookie');

#    print "Got cookie: '$self->{cookie}'\n";

    # Go home.
    $req = new HTTP::Request GET =>'http://www.orkut.com/Home.aspx';
    $req->header(Cookie => $self->{cookie});
    $res = $self->{ua}->request($req);

    # Check the outcome of the response
    if ($res->is_success) {
		# Get the user ID.
		if ($res->content =~ /FriendsList\.aspx\?uid=([0-9]+)/sgi) {
			$self->{uid} = $1;
		} 
		elsif ($res->content =~ /session expired/sgi) {
			Carp::croak("Failed to login.\n");
		}
		else {
			Carp::croak("Didn't find the UID on the page.\n".
						$res->code . ": ", $res->message, "\n\n".
						$res->content);
		}
    } else {
		print $res->code . ": ", $res->message, "\n";
		print $res->headers->scan(\&pnt);
		print $res->content;
		die;
    }
	return $self->{uid};
}

=item $o->getFriendsPage($uid);

=head1 DESCRIPTION

Returns the friends page.

=cut

sub getFriendsPage {
	my $self = shift;
    my $uid = shift;

    my $req = new HTTP::Request GET =>"http://www.orkut.com/FriendsList.aspx?uid=$uid";
    $req->header(Cookie => $self->{cookie});
    my $res = $self->{ua}->request($req);
    
    if ($res->is_success) {
		return $res->content;
    } else {
		Carp::croak($res->code . ": ", $res->message, "\n".
					$res->content);
    }
}

=item $o->friends($html);

=head1 DESCRIPTION

Returns a hash with friends if given the friends page.

=cut
sub friends {
	my $self = shift;
    $_ = shift;
    my @foo = split('<a');
    my %friends;
    for (@foo) {
		if (/FriendsList\.aspx\?uid=(\d+)\" class=\"P\">(.*)<\/a>/smg) {
			if (! /<img/) {
				$friends{$1} = $2;
			}
		}
    }
    return %friends;
}

